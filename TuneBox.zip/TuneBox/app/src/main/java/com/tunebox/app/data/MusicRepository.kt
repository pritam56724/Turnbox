package com.tunebox.app.data

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context) {
    private val db = TuneBoxDb(context)
    @Volatile private var songsCache: List<Song> = emptyList()

    suspend fun scan(): List<Song> = withContext(Dispatchers.IO) {
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.ALBUM_ID)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val result = buildList {
            context.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST); val album = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM); val duration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION); val date = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED); val albumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                while(c.moveToNext()) add(Song(c.getLong(id),c.getString(title).orEmpty().ifBlank { "Unknown title" },c.getString(artist).orEmpty().ifBlank { "Unknown artist" },c.getString(album).orEmpty().ifBlank { "Unknown album" },c.getLong(duration),c.getLong(date),c.getLong(albumId),ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,c.getLong(id)).toString()))
            }
        }.map { it.copy(playCount = db.playCount(it.id)) }
        songsCache = result
        result
    }
    fun songs(): List<Song> = songsCache
    fun favorites(): List<Song> = songsCache.filter { db.isFavorite(it.id) }
    fun recentlyPlayed(): List<Song> = db.historyIds().mapNotNull { id -> songsCache.find { it.id == id } }
    fun toggleFavorite(id: Long) = db.toggleFavorite(id)
    fun isFavorite(id: Long) = db.isFavorite(id)
    fun recordPlayed(id: Long) { db.recordPlayed(id); songsCache = songsCache.map { if(it.id==id) it.copy(playCount=it.playCount+1) else it } }
    fun playlists() = db.playlists()
    fun createPlaylist(name:String)=db.createPlaylist(name)
    fun renamePlaylist(id:Long,name:String)=db.renamePlaylist(id,name)
    fun deletePlaylist(id:Long)=db.deletePlaylist(id)
    fun addToPlaylist(pid:Long,sid:Long)=db.addToPlaylist(pid,sid)
    fun removeFromPlaylist(pid:Long,sid:Long)=db.removeFromPlaylist(pid,sid)
    fun playlistSongs(pid:Long)=db.playlistSongIds(pid).mapNotNull { id -> songsCache.find { it.id==id } }
    fun setting(k:String,d:String)=db.setting(k,d)
    fun setSetting(k:String,v:String)=db.setSetting(k,v)
}
