package com.tunebox.app.playback

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.tunebox.app.data.PlayerState
import com.tunebox.app.data.Song
import com.tunebox.app.playback.mediaItemFromSong
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PlayerManager(context: Context, private val onPlayed: (Long) -> Unit, private val onPosition: (Long, Long) -> Unit = { _, _ -> }) {
    private val scope = CoroutineScope(Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state
    private val future: ListenableFuture<MediaController>
    private var controller: MediaController? = null
    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { publish(player) }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { mediaItem?.mediaId?.toLongOrNull()?.let(onPlayed); controller?.let(::publish) }
    }
    init {
        scope.launch { while (true) { kotlinx.coroutines.delay(500); controller?.let { publish(it); it.currentMediaItem?.mediaId?.toLongOrNull()?.let { id -> onPosition(id, it.currentPosition) } } } }
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try { controller = future.get(); controller?.addListener(listener); controller?.let(::publish) } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(context))
    }
    private fun publish(p: Player) {
        val item = p.currentMediaItem
        _state.value = PlayerState(item?.mediaId?.toLongOrNull()?.let { id -> currentSongResolver(id) }, p.isPlaying, p.currentPosition, p.duration.coerceAtLeast(0), p.shuffleModeEnabled, p.repeatMode)
    }
    private var currentSongResolver: (Long) -> Song? = { null }
    fun setSongResolver(resolver: (Long)->Song?) { currentSongResolver = resolver; controller?.let(::publish) }
    fun restore(song: Song, position: Long) { controller?.let { c -> c.setMediaItem(mediaItemFromSong(song)); c.prepare(); c.seekTo(position.coerceAtLeast(0)) } }
    fun play(song: Song, queue: List<Song> = listOf(song)) {
        val c = controller ?: return
        val items = queue.map { mediaItemFromSong(it) }
        val index = queue.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        c.setMediaItems(items, index, 0L); c.prepare(); c.play()
    }
    fun toggle() { controller?.let { if(it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNext() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(position:Long){ controller?.seekTo(position) }
    fun shuffle(enabled:Boolean){ controller?.shuffleModeEnabled=enabled }
    fun repeat(mode:Int){ controller?.repeatMode=mode }
    fun addToQueue(song:Song){ controller?.addMediaItem(mediaItemFromSong(song)) }
    fun queue(): List<MediaItem> = controller?.let { (0 until it.mediaItemCount).map(it::getMediaItemAt) } ?: emptyList()
    fun volume(): Float = controller?.volume ?: 1f
    fun setVolume(v: Float) { controller?.volume = v.coerceIn(0f, 1f) }
    fun release() { controller?.removeListener(listener); controller?.release(); future.cancel(true); controller=null }
}
