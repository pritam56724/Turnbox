package com.tunebox.app.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunebox.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF0E1116)
private val Surface = Color(0xFF171B22)
private val Surface2 = Color(0xFF202630)
private val Accent = Color(0xFFB7F36B)

@Composable fun TuneBoxApp(vm: AppViewModel, onRequestMusicPermission: () -> Unit, onDeleteSong: (Song) -> Unit = {}) {
    val songs by vm.songs.collectAsStateWithLifecycle(); val playlists by vm.playlists.collectAsStateWithLifecycle(); val favorites by vm.favorites.collectAsStateWithLifecycle(); val recent by vm.recent.collectAsStateWithLifecycle(); val state by vm.playerState.collectAsStateWithLifecycle(); val query by vm.query.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(0) }; var darkTheme by rememberSaveable { mutableStateOf(true) }; var showPlayer by remember { mutableStateOf(false) }; var showSearch by remember { mutableStateOf(false) }; var playlistDetail by remember { mutableStateOf<Playlist?>(null) }; var showSettings by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = if(darkTheme) darkColorScheme(background=Ink,surface=Surface,primary=Accent,onPrimary=Color.Black,secondary=Accent,onBackground=Color.White,onSurface=Color.White) else lightColorScheme(primary=Color(0xFF4D6500),secondary=Color(0xFF596248))) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            Scaffold(containerColor=MaterialTheme.colorScheme.background, bottomBar={ if(!showPlayer && playlistDetail==null && !showSettings) BottomBar(tab){tab=it} }) { pad ->
                when {
                    showSettings -> SettingsScreen(vm, Modifier.padding(pad), onBack={showSettings=false}, darkTheme=darkTheme, onDarkThemeChange={darkTheme=it})
                    playlistDetail != null -> PlaylistDetailScreen(vm, playlistDetail!!, Modifier.padding(pad), onBack={playlistDetail=null})
                    else -> when(tab){
                        0 -> HomeScreen(vm, recent, state, Modifier.padding(pad), onSong={vm.play(it,songs);showPlayer=true}, onOpenPlayer={showPlayer=true}, onSearch={showSearch=true}, onSettings={showSettings=true})
                        1 -> SongsScreen(vm, songs, state, Modifier.padding(pad), onSong={vm.play(it,songs);showPlayer=true}, onSearch={showSearch=true}, onDeleteSong=onDeleteSong)
                        2 -> PlaylistsScreen(vm, playlists, Modifier.padding(pad), onOpen={playlistDetail=it})
                        else -> FavoritesScreen(vm, favorites, Modifier.padding(pad), onSong={vm.play(it,favorites);showPlayer=true}, onDeleteSong=onDeleteSong)
                    }
                }
            }
            AnimatedVisibility(showPlayer && playlistDetail==null && !showSettings, enter=slideInVertically{it}+fadeIn(), exit=slideOutVertically{it}+fadeOut()) { PlayerScreen(vm, state, songs, onBack={showPlayer=false}) }
            if(showSearch) SearchDialog(vm, songs, playlists, onClose={showSearch=false}, onSong={vm.play(it,songs);showSearch=false;showPlayer=true}, onDeleteSong=onDeleteSong)
        }
    }
}

@Composable private fun BottomBar(selected:Int,onSelect:(Int)->Unit){NavigationBar(containerColor=Surface){listOf("Home" to Icons.Default.Home,"Songs" to Icons.Default.MusicNote,"Playlists" to Icons.Default.QueueMusic,"Favorites" to Icons.Default.Favorite).forEachIndexed{index,(label,icon)->NavigationBarItem(selected==index,onClick={onSelect(index)},icon={Icon(icon,label)},label={Text(label)})}}}

@Composable private fun Header(title:String, onSearch:(()->Unit)?=null, onSettings:(()->Unit)?=null, onBack:(()->Unit)?=null){Row(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=16.dp),verticalAlignment=Alignment.CenterVertically){if(onBack!=null){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Back")};Spacer(Modifier.width(6.dp))};Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));onSearch?.let{IconButton(onClick=it){Icon(Icons.Default.Search,"Search")}};onSettings?.let{IconButton(onClick=it){Icon(Icons.Default.Settings,"Settings")}}}}

@Composable private fun HomeScreen(vm:AppViewModel,recent:List<Song>,state:PlayerState,modifier:Modifier,onSong:(Song)->Unit,onOpenPlayer:()->Unit,onSearch:()->Unit,onSettings:()->Unit){LazyColumn(modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=96.dp)){item{Header("Good evening 👋",onSearch,onSettings)};item{SearchPill(onSearch)};item{SectionTitle("Recently Played")};if(recent.isEmpty())item{EmptyCard("No recently played songs","Start playing music and your latest tracks will appear here.") } else item{LazyRow(contentPadding=PaddingValues(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){items(recent.take(10)){s->Column(Modifier.width(142.dp).clickable{onSong(s)}){Artwork(s,Modifier.size(142.dp).clip(RoundedCornerShape(20.dp)));Spacer(Modifier.height(8.dp));Text(s.title,maxLines=1,fontWeight=FontWeight.SemiBold);Text(s.artist,maxLines=1,color=Color.White.copy(.6f),fontSize=12.sp)}}}};item{SectionTitle("Your Library")};item{LibraryGrid(onTab={})};item{Spacer(Modifier.height(12.dp))};item{MiniPlayer(state,onOpenPlayer,vm)} }}

@Composable private fun SearchPill(onClick:()->Unit){Row(Modifier.padding(horizontal=20.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface).clickable{onClick()}.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Search,"Search",tint=Color.White.copy(.6f));Spacer(Modifier.width(10.dp));Text("Search songs, artists, albums...",color=Color.White.copy(.55f))}}
@Composable private fun SectionTitle(text:String){Text(text,Modifier.padding(horizontal=20.dp,vertical=18.dp),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
@Composable private fun LibraryGrid(onTab:(Int)->Unit){val items=listOf("🎵" to "All Songs","❤️" to "Favorites","📁" to "Playlists","🎤" to "Artists","💿" to "Albums");Column(Modifier.padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items.chunked(2).forEach{row->Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){row.forEach{(emoji,label)->Card(Modifier.weight(1f),colors=CardDefaults.cardColors(containerColor=Surface),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text(emoji,fontSize=24.sp);Spacer(Modifier.height(8.dp));Text(label,fontWeight=FontWeight.SemiBold)}}}}}}}

@Composable private fun SongsScreen(vm:AppViewModel,songs:List<Song>,state:PlayerState,modifier:Modifier,onSong:(Song)->Unit,onSearch:()->Unit,onDeleteSong:(Song)->Unit){val sort by vm.sort.collectAsStateWithLifecycle();Column(modifier.fillMaxSize()){Header("Songs",onSearch);Row(Modifier.padding(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){SortMode.values().forEach{s->if(s==sort)AssistChip(onClick={vm.setSort(s)},label={Text(s.label)},leadingIcon={Icon(Icons.Default.Check,"Selected",Modifier.size(16.dp))})}};Spacer(Modifier.height(8.dp));if(songs.isEmpty())EmptyCard("No music found","Add some music to your device and we'll find it here.",Modifier.padding(20.dp)) else LazyColumn(contentPadding=PaddingValues(bottom=100.dp)){items(vm.sortedSongs(),key={it.id}){s->SongRow(vm,s,state.currentSong?.id==s.id,onSong,onDeleteSong)}}}}

@Composable private fun FavoritesScreen(vm:AppViewModel,songs:List<Song>,modifier:Modifier,onSong:(Song)->Unit,onDeleteSong:(Song)->Unit = {}){Column(modifier.fillMaxSize()){Header("Favorites");if(songs.isEmpty())EmptyCard("No favorites yet","Tap the heart on any song to save it here.",Modifier.padding(20.dp)) else LazyColumn(contentPadding=PaddingValues(bottom=100.dp)){items(songs,key={it.id}){s->SongRow(vm,s,false,onSong,onDeleteSong)}}}}

@Composable
private fun SongRow(
    vm: AppViewModel,
    s: Song,
    isCurrent: Boolean,
    onSong: (Song) -> Unit,
    onDeleteSong: (Song) -> Unit = {}
) {
    var menu by remember { mutableStateOf(false) }
    var showPlaylists by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    val playlists by vm.playlists.collectAsStateWithLifecycle()

    Row(
        Modifier.fillMaxWidth().clickable { onSong(s) }.padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(s, Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, maxLines = 1, fontWeight = FontWeight.SemiBold)
            Text("${s.artist} • ${s.album}", maxLines = 1, color = MaterialTheme.colorScheme.onBackground.copy(.55f), fontSize = 12.sp)
        }
        if (isCurrent) Icon(Icons.Default.GraphicEq, "Playing", tint = Accent)
        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem({ Text("Play") }, { vm.play(s); menu = false })
            DropdownMenuItem({ Text("Add to Queue") }, { vm.enqueue(s); menu = false })
            DropdownMenuItem({ Text(if (vm.isFavorite(s.id)) "Remove from Favorites" else "Add to Favorites") }, { vm.toggleFavorite(s); menu = false })
            DropdownMenuItem({ Text("Add to Playlist") }, { menu = false; showPlaylists = true })
            DropdownMenuItem({ Text("Song Information") }, { menu = false; showInfo = true })
            DropdownMenuItem({ Text("Delete") }, { menu = false; onDeleteSong(s) })
        }
    }
    if (showPlaylists) {
        AlertDialog(
            onDismissRequest = { showPlaylists = false },
            title = { Text("Add to Playlist") },
            text = {
                if (playlists.isEmpty()) Text("Create a playlist first.")
                else Column {
                    playlists.forEach { p ->
                        Text(
                            p.name,
                            Modifier.fillMaxWidth().clickable { vm.addToPlaylist(p, s); showPlaylists = false }.padding(vertical = 12.dp),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPlaylists = false }) { Text("Cancel") } }
        )
    }
    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text(s.title) },
            text = { Column { Text("Artist: ${s.artist}"); Text("Album: ${s.album}"); Text("Duration: ${formatMs(s.duration)}") } },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Close") } }
        )
    }
}

@Composable private fun MiniPlayer(state:PlayerState,onOpen:()->Unit,vm:AppViewModel){val s=state.currentSong?:return;Row(Modifier.padding(horizontal=12.dp,vertical=8.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface2).clickable{onOpen()}.padding(8.dp),verticalAlignment=Alignment.CenterVertically){Artwork(s,Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)));Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(s.title,maxLines=1,fontWeight=FontWeight.SemiBold);Text(s.artist,maxLines=1,fontSize=12.sp,color=Color.White.copy(.55f))};IconButton(onClick={vm.toggle()}){Icon(if(state.isPlaying)Icons.Default.Pause else Icons.Default.PlayArrow,if(state.isPlaying)"Pause" else "Play")};IconButton(onClick={vm.next()}){Icon(Icons.Default.SkipNext,"Next")}}}

@Composable private fun PlayerScreen(vm:AppViewModel,state:PlayerState,songs:List<Song>,onBack:()->Unit){val s=state.currentSong?:return;var sleepMenu by remember{mutableStateOf(false)};var queueOpen by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal=24.dp)){Row(Modifier.fillMaxWidth().padding(top=12.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.KeyboardArrowDown,"Close")};Text("NOW PLAYING",Modifier.weight(1f),fontSize=12.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onBackground.copy(.55f));Box{IconButton(onClick={sleepMenu=true}){Icon(Icons.Default.Bedtime,"Sleep timer")};DropdownMenu(expanded=sleepMenu,onDismissRequest={sleepMenu=false}){DropdownMenuItem({Text("15 minutes")},{vm.startSleepTimer(15);sleepMenu=false});DropdownMenuItem({Text("30 minutes")},{vm.startSleepTimer(30);sleepMenu=false});DropdownMenuItem({Text("45 minutes")},{vm.startSleepTimer(45);sleepMenu=false});DropdownMenuItem({Text("60 minutes")},{vm.startSleepTimer(60);sleepMenu=false});DropdownMenuItem({Text("End of current song")},{vm.startSleepAfterCurrent();sleepMenu=false})}}};Spacer(Modifier.height(20.dp));Artwork(s,Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp)));Spacer(Modifier.height(26.dp));Text(s.title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text(s.artist,color=MaterialTheme.colorScheme.onBackground.copy(.6f),fontSize=15.sp);Spacer(Modifier.height(18.dp));Slider(value=if(state.duration>0)state.position.toFloat()/state.duration else 0f,onValueChange={vm.seek((it*state.duration).toLong())},valueRange=0f..1f,colors=SliderDefaults.colors(thumbColor=Accent,activeTrackColor=Accent));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(formatMs(state.position),fontSize=12.sp,color=MaterialTheme.colorScheme.onBackground.copy(.5f));Text(formatMs(state.duration),fontSize=12.sp,color=MaterialTheme.colorScheme.onBackground.copy(.5f))};Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){IconButton(onClick={vm.shuffle(!state.shuffle)}){Icon(Icons.Default.Shuffle,"Shuffle",tint=if(state.shuffle)Accent else MaterialTheme.colorScheme.onBackground)};IconButton(onClick={vm.previous()}){Icon(Icons.Default.SkipPrevious,"Previous",Modifier.size(32.dp))};FilledIconButton(onClick={vm.toggle()},modifier=Modifier.size(68.dp),colors=IconButtonDefaults.filledIconButtonColors(containerColor=Accent,contentColor=Color.Black)){Icon(if(state.isPlaying)Icons.Default.Pause else Icons.Default.PlayArrow,"Play",Modifier.size(34.dp))};IconButton(onClick={vm.next()}){Icon(Icons.Default.SkipNext,"Next",Modifier.size(32.dp))};IconButton(onClick={vm.repeat(if(state.repeatMode==2)0 else 2)}){Icon(Icons.Default.Repeat,"Repeat",tint=if(state.repeatMode==2)Accent else MaterialTheme.colorScheme.onBackground)}};Spacer(Modifier.height(14.dp));Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.VolumeDown,"Volume");Slider(value=0.8f,onValueChange=vm::setVolume,modifier=Modifier.weight(1f),colors=SliderDefaults.colors(thumbColor=Accent,activeTrackColor=Accent));Icon(Icons.Default.VolumeUp,"Volume")};Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceAround){TextButton(onClick={queueOpen=true}){Icon(Icons.Default.QueueMusic,"Queue");Spacer(Modifier.width(6.dp));Text("Queue")};TextButton(onClick={vm.toggleFavorite(s)}){Icon(if(vm.isFavorite(s.id))Icons.Default.Favorite else Icons.Default.FavoriteBorder,"Favorite",tint=if(vm.isFavorite(s.id))Accent else MaterialTheme.colorScheme.onBackground);Spacer(Modifier.width(6.dp));Text("Favorite")}}};if(queueOpen)AlertDialog(onDismissRequest={queueOpen=false},title={Text("Queue")},text={Column{songs.take(20).forEachIndexed{index,q->Row(Modifier.fillMaxWidth().clickable{vm.play(q,songs);queueOpen=false}.padding(vertical=8.dp),verticalAlignment=Alignment.CenterVertically){Text("${index+1}",Modifier.width(28.dp),color=MaterialTheme.colorScheme.onBackground.copy(.5f));Column{Text(q.title,fontWeight=FontWeight.SemiBold);Text(q.artist,fontSize=12.sp,color=MaterialTheme.colorScheme.onBackground.copy(.5f))}}}}},confirmButton={TextButton(onClick={queueOpen=false}){Text("Close")}})}

@Composable private fun PlaylistsScreen(vm:AppViewModel,playlists:List<Playlist>,modifier:Modifier,onOpen:(Playlist)->Unit){var create by remember{mutableStateOf(false)};Column(modifier.fillMaxSize()){Header("Playlists");Button(onClick={create=true},modifier=Modifier.padding(horizontal=20.dp).fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Accent,contentColor=Color.Black)){Icon(Icons.Default.Add,"Create");Spacer(Modifier.width(8.dp));Text("Create Playlist")};Spacer(Modifier.height(12.dp));if(playlists.isEmpty())EmptyCard("No playlists","Create your first playlist and start collecting songs.",Modifier.padding(20.dp)) else LazyColumn(contentPadding=PaddingValues(bottom=100.dp)){items(playlists,key={it.id}){p->Row(Modifier.fillMaxWidth().clickable{onOpen(p)}.padding(horizontal=20.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(68.dp).clip(RoundedCornerShape(16.dp)).background(Surface2),contentAlignment=Alignment.Center){Icon(Icons.Default.QueueMusic,"Playlist",tint=Accent,modifier=Modifier.size(30.dp))};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.songCount} songs",color=Color.White.copy(.55f),fontSize=12.sp)};Icon(Icons.Default.ChevronRight,"Open")}}}};if(create)TextInputDialog("Create Playlist","Playlist name",onDismiss={create=false},onConfirm={vm.createPlaylist(it);create=false})}

@Composable private fun PlaylistDetailScreen(vm:AppViewModel,p:Playlist,modifier:Modifier,onBack:()->Unit){val songs=vm.playlistSongs(p);var menu by remember{mutableStateOf(false)};var rename by remember{mutableStateOf(false)};Column(modifier.fillMaxSize()){Row(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=16.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Back")};Text(p.name,Modifier.weight(1f),style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);IconButton(onClick={menu=true}){Icon(Icons.Default.MoreVert,"More")};DropdownMenu(menu,{menu=false}){DropdownMenuItem({Text("Rename")},{menu=false;rename=true});DropdownMenuItem({Text("Delete playlist")},{menu=false;vm.deletePlaylist(p);onBack()})}};Row(Modifier.padding(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(onClick={songs.firstOrNull()?.let{vm.play(it,songs)}},enabled=songs.isNotEmpty()){Icon(Icons.Default.PlayArrow,"Play");Spacer(Modifier.width(6.dp));Text("Play all")};OutlinedButton(onClick={val shuffled=songs.shuffled();shuffled.firstOrNull()?.let{vm.play(it,shuffled)}},enabled=songs.isNotEmpty()){Icon(Icons.Default.Shuffle,"Shuffle");Spacer(Modifier.width(6.dp));Text("Shuffle")}};Spacer(Modifier.height(12.dp));if(songs.isEmpty())EmptyCard("No songs yet","Use a song's menu to add it to this playlist.",Modifier.padding(20.dp)) else LazyColumn(contentPadding=PaddingValues(bottom=100.dp)){items(songs,key={it.id}){s->SongRow(vm,s,false){vm.play(s,songs)}}}};if(rename)TextInputDialog("Rename Playlist","Playlist name",onDismiss={rename=false},onConfirm={vm.renamePlaylist(p,it);rename=false})}

@Composable private fun SearchDialog(vm:AppViewModel,songs:List<Song>,playlists:List<Playlist>,onClose:()->Unit,onSong:(Song)->Unit,onDeleteSong:(Song)->Unit){Dialog(onDismissRequest=onClose){Surface(Modifier.fillMaxWidth().fillMaxHeight(.86f),shape=RoundedCornerShape(28.dp),color=Surface){Column{Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onClose){Icon(Icons.Default.Close,"Close")};OutlinedTextField(value=vm.query.collectAsStateWithLifecycle().value,onValueChange=vm::setQuery,modifier=Modifier.weight(1f),singleLine=true,placeholder={Text("Search songs, artists, albums...")},leadingIcon={Icon(Icons.Default.Search,"Search")})};val result=vm.search();if(vm.query.collectAsStateWithLifecycle().value.isBlank())EmptyCard("Start searching","Find songs, artists, albums and playlists.",Modifier.padding(20.dp)) else LazyColumn{item{SectionTitle("Songs")};items(result.take(50)){s->SongRow(vm,s,false,onSong,onDeleteSong)};item{SectionTitle("Artists")};items(result.map{it.artist}.distinct().filter{it.contains(vm.query.collectAsStateWithLifecycle().value,true)}.take(20)){a->Text(a,Modifier.padding(horizontal=20.dp,vertical=8.dp),fontWeight=FontWeight.SemiBold)};item{SectionTitle("Albums")};items(result.map{it.album}.distinct().filter{it.contains(vm.query.collectAsStateWithLifecycle().value,true)}.take(20)){a->Text(a,Modifier.padding(horizontal=20.dp,vertical=8.dp),fontWeight=FontWeight.SemiBold)};item{SectionTitle("Playlists")};items(playlists.filter{it.name.contains(vm.query.collectAsStateWithLifecycle().value,true)}){p->Text(p.name,Modifier.padding(horizontal=20.dp,vertical=10.dp),fontWeight=FontWeight.SemiBold)}}}}}}

@Composable private fun SettingsScreen(vm:AppViewModel,modifier:Modifier,onBack:()->Unit,darkTheme:Boolean,onDarkThemeChange:(Boolean)->Unit){var gapless by rememberSaveable{mutableStateOf(true)};var resume by rememberSaveable{mutableStateOf(true)};var defaultShuffle by rememberSaveable{mutableStateOf(false)};var defaultRepeat by rememberSaveable{mutableStateOf(false)};var followSystem by rememberSaveable{mutableStateOf(false)};Column(modifier.fillMaxSize()){Header("Settings",onBack=onBack);LazyColumn(contentPadding=PaddingValues(bottom=40.dp)){item{SettingSection("Playback")};item{SettingRow("Gapless playback",gapless){gapless=it}};item{SettingRow("Resume playback",resume){resume=it}};item{SettingRow("Default shuffle",defaultShuffle){defaultShuffle=it}};item{SettingRow("Default repeat",defaultRepeat){defaultRepeat=it}};item{SettingSection("Appearance")};item{SettingRow("Dark mode",darkTheme){onDarkThemeChange(it)}};item{SettingRow("Follow system theme",followSystem){followSystem=it}};item{SettingSection("Library")};item{SettingRow("Rescan music",false){vm.scan()}};item{SettingSection("About")};item{Text("TuneBox 1.0",Modifier.padding(horizontal=20.dp,vertical=12.dp),color=MaterialTheme.colorScheme.onBackground.copy(.65f))};item{Text("Offline music player • No account • No cloud upload",Modifier.padding(horizontal=20.dp),color=MaterialTheme.colorScheme.onBackground.copy(.45f),fontSize=12.sp)}}}}
@Composable private fun SettingSection(t:String){Text(t,Modifier.padding(horizontal=20.dp,vertical=16.dp),color=Accent,fontWeight=FontWeight.Bold)}
@Composable private fun SettingRow(label:String,checked:Boolean,onChange:((Boolean)->Unit)?=null){Row(Modifier.fillMaxWidth().clickable(enabled=onChange!=null){onChange?.invoke(!checked)}.padding(horizontal=20.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.weight(1f));if(onChange!=null)Switch(checked=checked,onCheckedChange=onChange) else Text(if(checked)"On" else "Off",color=MaterialTheme.colorScheme.onBackground.copy(.5f),fontSize=12.sp)}}

@Composable private fun EmptyCard(title:String,body:String,modifier:Modifier=Modifier){Column(modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Surface).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.LibraryMusic,"Empty",Modifier.size(42.dp),tint=Accent);Spacer(Modifier.height(12.dp));Text(title,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(6.dp));Text(body,color=Color.White.copy(.55f),fontSize=13.sp)}}
@Composable private fun Artwork(song:Song,modifier:Modifier){val context=LocalContext.current; val bitmap by produceState<Bitmap?>(null,song.uri){value=withContext(Dispatchers.IO){try{MediaMetadataRetriever().use{r->r.setDataSource(context, Uri.parse(song.uri));r.embeddedPicture?.let{android.graphics.BitmapFactory.decodeByteArray(it,0,it.size)}}}catch(_:Exception){null}}};if(bitmap!=null)Image(bitmap!!.asImageBitmap(),song.title,modifier,contentScale=ContentScale.Crop) else Box(modifier.background(Surface2),contentAlignment=Alignment.Center){Icon(Icons.Default.MusicNote,"Album art",tint=Accent,modifier=Modifier.size(32.dp))}}
private fun formatMs(ms:Long):String{val sec=(ms.coerceAtLeast(0)/1000);return "%d:%02d".format(sec/60,sec%60)}
@Composable private fun TextInputDialog(title:String,label:String,onDismiss:()->Unit,onConfirm:(String)->Unit){var text by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={OutlinedTextField(text,{text=it},label={Text(label)},singleLine=true)},confirmButton={TextButton(onClick={onConfirm(text)}){Text("Create")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}
