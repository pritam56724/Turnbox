package com.tunebox.app.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class TuneBoxDb(context: Context) : SQLiteOpenHelper(context, "tunebox.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE favorites(song_id INTEGER PRIMARY KEY)")
        db.execSQL("CREATE TABLE history(song_id INTEGER PRIMARY KEY, last_played INTEGER NOT NULL, play_count INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE playlists(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, image_uri TEXT)")
        db.execSQL("CREATE TABLE playlist_songs(playlist_id INTEGER NOT NULL, song_id INTEGER NOT NULL, position INTEGER NOT NULL, PRIMARY KEY(playlist_id,song_id))")
        db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun isFavorite(id: Long): Boolean = readableDatabase.rawQuery("SELECT 1 FROM favorites WHERE song_id=?", arrayOf(id.toString())).use { it.moveToFirst() }
    fun toggleFavorite(id: Long): Boolean {
        val db = writableDatabase
        return if (isFavorite(id)) { db.delete("favorites", "song_id=?", arrayOf(id.toString())); false }
        else { db.insert("favorites", null, android.content.ContentValues().apply { put("song_id", id) }); true }
    }
    fun favoriteIds(): Set<Long> = readableDatabase.rawQuery("SELECT song_id FROM favorites", null).use { c -> buildSet { while (c.moveToNext()) add(c.getLong(0)) } }
    fun recordPlayed(id: Long) {
        val db = writableDatabase
        db.execSQL("INSERT INTO history(song_id,last_played,play_count) VALUES(?,?,1) ON CONFLICT(song_id) DO UPDATE SET last_played=excluded.last_played, play_count=history.play_count+1", arrayOf(id, System.currentTimeMillis()))
    }
    fun historyIds(): List<Long> = readableDatabase.rawQuery("SELECT song_id FROM history ORDER BY last_played DESC LIMIT 30", null).use { c -> buildList { while (c.moveToNext()) add(c.getLong(0)) } }
    fun playCount(id: Long): Int = readableDatabase.rawQuery("SELECT play_count FROM history WHERE song_id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    fun createPlaylist(name: String): Long = writableDatabase.insert("playlists", null, android.content.ContentValues().apply { put("name", name) })
    fun playlists(): List<Playlist> = readableDatabase.rawQuery("SELECT p.id,p.name,p.image_uri,(SELECT COUNT(*) FROM playlist_songs ps WHERE ps.playlist_id=p.id) FROM playlists p ORDER BY p.name", null).use { c -> buildList { while(c.moveToNext()) add(Playlist(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3))) } }
    fun renamePlaylist(id: Long, name: String) { writableDatabase.execSQL("UPDATE playlists SET name=? WHERE id=?", arrayOf(name,id)) }
    fun deletePlaylist(id: Long) { writableDatabase.delete("playlist_songs","playlist_id=?",arrayOf(id.toString())); writableDatabase.delete("playlists","id=?",arrayOf(id.toString())) }
    fun addToPlaylist(pid: Long, sid: Long) { writableDatabase.execSQL("INSERT OR IGNORE INTO playlist_songs(playlist_id,song_id,position) VALUES(?,?,COALESCE((SELECT MAX(position)+1 FROM playlist_songs WHERE playlist_id=?),0))", arrayOf(pid,sid,pid)) }
    fun removeFromPlaylist(pid: Long, sid: Long) { writableDatabase.delete("playlist_songs","playlist_id=? AND song_id=?",arrayOf(pid.toString(),sid.toString())) }
    fun playlistSongIds(pid: Long): List<Long> = readableDatabase.rawQuery("SELECT song_id FROM playlist_songs WHERE playlist_id=? ORDER BY position", arrayOf(pid.toString())).use { c -> buildList { while(c.moveToNext()) add(c.getLong(0)) } }
    fun setSetting(key:String,value:String){ writableDatabase.execSQL("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",arrayOf(key,value)) }
    fun setting(key:String, fallback:String):String = readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?",arrayOf(key)).use { if(it.moveToFirst()) it.getString(0) else fallback }
}
