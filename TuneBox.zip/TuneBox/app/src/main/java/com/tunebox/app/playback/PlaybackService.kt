package com.tunebox.app.playback

import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var player: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()
        val p = ExoPlayer.Builder(this).setAudioAttributes(AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build(), true).setHandleAudioBecomingNoisy(true).build()
        p.setWakeMode(C.WAKE_MODE_LOCAL)
        player = p
        session = MediaSession.Builder(this, p).setId("TuneBoxSession").build()
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session
    override fun onDestroy() {
        session?.release(); session = null
        player?.release(); player = null
        super.onDestroy()
    }
}

fun mediaItemFromSong(song: com.tunebox.app.data.Song): MediaItem = MediaItem.Builder().setMediaId(song.id.toString()).setUri(song.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist).setAlbumTitle(song.album).build()).build()
