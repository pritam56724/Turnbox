package com.tunebox.app.data

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val dateAdded: Long,
    val albumId: Long,
    val uri: String,
    val playCount: Int = 0
)

data class Playlist(val id: Long, val name: String, val imageUri: String?, val songCount: Int)

data class PlayerState(
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val position: Long = 0,
    val duration: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = 0
)

enum class SortMode(val label: String) { NAME("Song name"), ARTIST("Artist"), ALBUM("Album"), RECENT("Recently added"), PLAYED("Most played") }
