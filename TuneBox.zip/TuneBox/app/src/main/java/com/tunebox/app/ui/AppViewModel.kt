package com.tunebox.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tunebox.app.data.*
import com.tunebox.app.playback.PlayerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as com.tunebox.app.TuneBoxApplication).repository
    private val player = PlayerManager(app, { repo.recordPlayed(it); refresh() }) { id, pos -> repo.setSetting("last_song_id", id.toString()); repo.setSetting("last_position", pos.toString()) }
    val playerState: StateFlow<PlayerState> = player.state
    private val _songs = MutableStateFlow<List<Song>>(emptyList()); val songs:StateFlow<List<Song>>=_songs
    private val _playlists = MutableStateFlow<List<Playlist>>(emptyList()); val playlists:StateFlow<List<Playlist>>=_playlists
    private val _recent = MutableStateFlow<List<Song>>(emptyList()); val recent:StateFlow<List<Song>>=_recent
    private val _favorites = MutableStateFlow<List<Song>>(emptyList()); val favorites:StateFlow<List<Song>>=_favorites
    private val _sort = MutableStateFlow(SortMode.NAME); val sort:StateFlow<SortMode>=_sort
    private val _query = MutableStateFlow(""); val query:StateFlow<String>=_query
    private var sleepJob: Job? = null
    private val _isScanning = MutableStateFlow(false); val isScanning:StateFlow<Boolean>=_isScanning
    init { player.setSongResolver { id -> _songs.value.find { it.id == id } }; refresh() }
    fun scan() { viewModelScope.launch { _isScanning.value=true; _songs.value=repo.scan(); _isScanning.value=false; refresh(); val resumeEnabled = repo.setting("resume_playback","true").toBoolean(); if(resumeEnabled){ val id=repo.setting("last_song_id","").toLongOrNull(); val pos=repo.setting("last_position","0").toLongOrNull()?:0L; _songs.value.find{it.id==id}?.let{player.restore(it,pos)} } } }
    fun refresh(){ _favorites.value=repo.favorites(); _recent.value=repo.recentlyPlayed(); _playlists.value=repo.playlists() }
    fun play(song:Song, queue:List<Song>=_songs.value){ player.play(song,queue) }
    fun toggle(){player.toggle()}; fun next(){player.next()}; fun previous(){player.previous()}; fun seek(p:Long){player.seekTo(p)}
    fun shuffle(v:Boolean){player.shuffle(v)}; fun repeat(v:Int){player.repeat(v)}; fun enqueue(s:Song){player.addToQueue(s)}
    fun setVolume(v:Float)=player.setVolume(v)
    fun startSleepTimer(minutes:Int){ sleepJob?.cancel(); if(minutes<=0)return; sleepJob=viewModelScope.launch{delay(minutes*60_000L); if(playerState.value.isPlaying) player.toggle(); } }
    fun startSleepAfterCurrent(){ sleepJob?.cancel(); sleepJob=viewModelScope.launch{ while(isActive){ delay(500); val st=playerState.value; if(st.currentSong!=null && st.duration>0 && st.position >= st.duration-1000L){ if(st.isPlaying) player.toggle(); break } } } }
    fun toggleFavorite(s:Song){repo.toggleFavorite(s.id); refresh()}; fun isFavorite(id:Long)=repo.isFavorite(id)
    fun createPlaylist(name:String){if(name.isNotBlank()){repo.createPlaylist(name.trim());refresh()}}
    fun renamePlaylist(p:Playlist,name:String){if(name.isNotBlank()){repo.renamePlaylist(p.id,name.trim());refresh()}}
    fun deletePlaylist(p:Playlist){repo.deletePlaylist(p.id);refresh()}
    fun addToPlaylist(p:Playlist,s:Song){repo.addToPlaylist(p.id,s.id);refresh()}
    fun removeFromPlaylist(p:Playlist,s:Song){repo.removeFromPlaylist(p.id,s.id);refresh()}
    fun playlistSongs(p:Playlist)=repo.playlistSongs(p.id)
    fun setSort(s:SortMode){_sort.value=s}
    fun setQuery(q:String){_query.value=q}
    fun sortedSongs():List<Song>{ val list=_songs.value; return when(_sort.value){SortMode.NAME->list.sortedBy{it.title.lowercase()};SortMode.ARTIST->list.sortedBy{it.artist.lowercase()};SortMode.ALBUM->list.sortedBy{it.album.lowercase()};SortMode.RECENT->list.sortedByDescending{it.dateAdded};SortMode.PLAYED->list.sortedByDescending{it.playCount}} }
    fun search():List<Song>{val q=_query.value.trim().lowercase();if(q.isBlank())return emptyList();return _songs.value.filter{it.title.lowercase().contains(q)||it.artist.lowercase().contains(q)||it.album.lowercase().contains(q)}}
    override fun onCleared(){player.release();super.onCleared()}
}
