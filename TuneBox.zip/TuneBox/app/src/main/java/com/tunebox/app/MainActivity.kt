package com.tunebox.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.IntentSenderRequest
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import com.tunebox.app.ui.AppViewModel
import com.tunebox.app.ui.TuneBoxApp

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { if (it.resultCode == RESULT_OK) vm.scan() }
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        if (results.values.any { it }) vm.scan()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TuneBoxApp(vm, onRequestMusicPermission = ::requestMusicPermission, onDeleteSong = ::deleteSong)
            LaunchedEffect(Unit) { requestMusicPermission() }
        }
    }
    private fun deleteSong(song: com.tunebox.app.data.Song) {
        val uri = Uri.parse(song.uri)
        if (Build.VERSION.SDK_INT >= 30) {
            val request = MediaStore.createDeleteRequest(contentResolver, listOf(uri))
            deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
        } else {
            try { contentResolver.delete(uri, null, null); vm.scan() } catch (_: SecurityException) { requestMusicPermission() }
        }
    }

    private fun requestMusicPermission() {
        val permissions = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.READ_MEDIA_AUDIO) else add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val needed = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isEmpty()) vm.scan() else permissionLauncher.launch(needed.toTypedArray())
    }
}
