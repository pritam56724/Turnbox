package com.tunebox.app

import android.app.Application
import com.tunebox.app.data.MusicRepository

class TuneBoxApplication : Application() {
    lateinit var repository: MusicRepository
        private set
    override fun onCreate() { super.onCreate(); repository = MusicRepository(this) }
}
