# TuneBox

TuneBox is a local-first Android music player built with Kotlin + Jetpack Compose + AndroidX Media3. It does not require login, a backend, cloud storage, or an internet connection for playback.

## Included

- Dark-first modern Compose UI with Home, Songs, Playlists and Favorites tabs
- MediaStore device music scan with Android-version-aware audio permission
- Metadata and embedded album-art loading
- Media3 ExoPlayer + MediaSessionService for background/lock-screen playback
- System media notification, headset/Bluetooth controls and audio-focus handling
- Play/pause/previous/next/seek/shuffle/repeat/queue
- Favorites, playlists, history and play counts stored locally in SQLite
- Global search across songs, artists, albums and playlists
- Sorting by title, artist, album, recently added and most played
- Sleep timer options
- Delete flow using Android's user-confirmed MediaStore deletion request on modern Android
- Empty states and defensive handling for unreadable media/album artwork

## Open and run

1. Install the current Android Studio.
2. Open the `TuneBox` folder.
3. Let Android Studio install/sync the required Gradle and Android SDK components.
4. Use a physical Android device or emulator running Android 6.0+.
5. Run the `app` configuration.
6. Grant audio access when TuneBox asks.
7. Put music on the device, then use **Settings → Rescan music** if it was added after launch.

The project uses Android Gradle Plugin 9.0.1/Gradle 9.1-compatible configuration, compileSdk 37, minSdk 23, Media3 1.11.1 and Compose BOM 2026.09.00.

## Architecture

- `data/`: MediaStore scanning, models and local SQLite persistence
- `playback/`: Media3 foreground playback service and UI controller
- `ui/`: Compose screens and application state
- `MainActivity`: permissions and Android system deletion confirmation

Playback intentionally lives in `PlaybackService`, separate from the UI. This is the Android-recommended Media3 pattern for background playback and external media controls.
